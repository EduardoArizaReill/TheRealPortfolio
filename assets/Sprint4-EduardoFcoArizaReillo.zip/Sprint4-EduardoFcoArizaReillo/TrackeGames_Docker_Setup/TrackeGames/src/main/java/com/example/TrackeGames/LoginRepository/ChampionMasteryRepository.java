package com.example.TrackeGames.LoginRepository;

import com.example.TrackeGames.LoginDomain.ChampionMastery;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChampionMasteryRepository extends JpaRepository<ChampionMastery, Integer> {
}
