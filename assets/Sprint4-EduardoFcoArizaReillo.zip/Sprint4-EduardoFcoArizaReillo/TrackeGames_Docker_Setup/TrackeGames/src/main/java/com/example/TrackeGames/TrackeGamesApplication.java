package com.example.TrackeGames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrackeGamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrackeGamesApplication.class, args);
	}

}
