package com.example.TrackeGames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackeGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
